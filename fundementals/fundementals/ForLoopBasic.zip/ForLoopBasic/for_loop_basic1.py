
for i in range(1,151):
    print(i);

for i in range(0,1000,5):
    print(i)
    


for i in range(1,100,1):
    print(i)
    if i%5==0:
        print("Coding")
    if i%10==0:
        print("Coding Dojo")

sum=0
for q in range(1, 500000, 2):
    sum += q
print(sum)
    
for i in range(2018,0,-4):
    print(i)
    

for i in range(1,111,4):
        print(i)
